package Assignment3;


import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class muti {
	int n;
	public void begin(){
		long start = System.currentTimeMillis();	// ��¼��ʼʱ��


		
        new Thread(new Runnable(){ 
	public void run() {
		for(n=1574;n<1580;n++){
		Main2014302580311 info=new Main2014302580311();
		Document doc = info.getDocument("http://cs.whu.edu.cn/plus/view.php?aid="+n);
		Elements elements1=doc.select("[class=content fn_clear]");
		Elements elements2 = elements1.select("li");
		for(int n1=0;n1<=8;n1++){
		String grjj = elements2.get(n1).text();
		System.out.println(grjj);
		}
		Elements elements3=elements1.select("[class=info_list_ct]");
		String grjj1=elements3.get(0).text();
		System.out.println(grjj1);
		
	}
		long end = System.currentTimeMillis();	
		long t=end-start;// ��¼����ʱ��
		System.out.println("���߳�����ʱ��="+t+"ms");
        }
	
	},"�߳�"+n).start();

	}

	public  void main(String[] arg){
	
	}
	

}

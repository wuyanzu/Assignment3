package Assignment3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class sql {

public static void main(String arg[]){
}

public void getIn() throws IOException{

	try{
	Connection con=null;
	Class.forName("com.mysql.jdbc.Driver").newInstance();
	con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/mydb?characterEncoding=utf8","root","123456");
	Statement stmt;
	stmt=con.createStatement();
	System.out.print("yes");
	long start = System.currentTimeMillis();	// ��¼��ʼʱ��
	Main2014302580311 info=new Main2014302580311();
	FileOutputStream fs = new FileOutputStream(new File("Information.txt"));
	PrintStream p = new PrintStream(fs);
	for(int n=1574;n<=1580;n++){
		 
		Document doc = info.getDocument("http://cs.whu.edu.cn/plus/view.php?aid="+n);
		Elements elements1=doc.select("[class=content fn_clear]");
		Elements elements2 = elements1.select("li");
		for(int i=0;i<=8;i++){
		String grjj = elements2.get(i).text();
		System.out.println(grjj);
		String a="INSERT INTO info(info1)"+ "VALUES('" +grjj+ "')";
		stmt.execute(a);
		}
		Elements elements3=elements1.select("[class=info_list_ct]");
		String grjj1=elements3.get(0).text();
		System.out.println(grjj1);
		String b="INSERT INTO info(info2)"+"VALUES('"+grjj1+"')";	
		stmt.execute(b);
		p.close();
		}	

	long end = System.currentTimeMillis();	
	long t=end-start;// ��¼����ʱ��
	System.out.println("���߳�����ʱ��="+t+"ms");

	
	}catch(Exception e){
		System.out.print("MYSQL ERROR:"+e.getMessage());
	}
	
	
}

}

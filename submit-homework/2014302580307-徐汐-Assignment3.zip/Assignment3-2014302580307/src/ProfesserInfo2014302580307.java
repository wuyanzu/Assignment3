import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ProfesserInfo2014302580307{
	String url;
	Document doc;
	String title;
	String name;
	String email;
	String phone;
	String ResDir;
	void getDoc() throws IOException{
		doc=Jsoup.connect(url).get();
	}
	void getTitle(){
		title = doc.title();
	}
	String getName(){
		Elements name1 =doc.getElementsByClass("title");
		name =name1.text();
		return name;
	}
	String getResDir(){
		Element ResDir1 = doc.select("p").first();
		ResDir = ResDir1.text();
		return ResDir;
	}
	String getEmail(){
		email = null;
		Pattern p1 =Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		Matcher m1 =p1.matcher(ResDir);
		while(m1.find()){
		email = m1.group();
		}
		return email;
	}
	String getPhone(){
		phone = null;
		Pattern p2=Pattern.compile("[0-9]+\\-+[0-9]{8}");
		Matcher m2=p2.matcher(ResDir);
		while(m2.find()){
			phone = m2.group();
		}
		return phone;
	}
}

import java.io.IOException;

import org.jsoup.nodes.Document;

public class Thread1 extends Thread{
	public String url;
	String name;
	String email;
	String phone;
	String ResDir;
	public Thread1(String url) {
        this.url = url;
    }
	public void run(){
		ProfesserInfo2014302580307 a=new ProfesserInfo2014302580307();
		try {
			a.url=url;
			a.getDoc();
			a.getTitle();
			name=a.getName();
			String ResDir=a.getResDir();
			String email;a.getEmail();
			String phone=a.getPhone();
		} catch (IOException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
}

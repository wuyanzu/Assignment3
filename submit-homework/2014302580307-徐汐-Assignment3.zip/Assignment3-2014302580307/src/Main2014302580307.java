import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.List;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.mysql.jdbc.PreparedStatement;

public class Main2014302580307 {
	public static void main(String[] args) throws Exception {
		String indexurl="http://staff.whu.edu.cn/";
		Document indexdoc = Jsoup.connect(indexurl).get();
		Elements urlsum= indexdoc.select("div.row a");

        Connection conn = null;
        String sql;
        String url = "jdbc:mysql://localhost:3306/javademo?"
                + "user=root&password=123456&useUnicode=true&characterEncoding=UTF8";
 
        try {
            Class.forName("com.mysql.jdbc.Driver");// ��̬����mysql����
            System.out.println("�ɹ�����MySQL��������");
            // һ��Connection����һ�����ݿ�����
            conn = DriverManager.getConnection(url);
            //�������ݿ�
            Statement stmt = conn.createStatement();
            sql = "select * from professor";
            System.out.println("ѡ�����ݿ�ɹ�");
            int result = 0;
            long time1=System.currentTimeMillis();
            //��������url����ץȡ���ݸ�ֵ����professor�ı���
            for(Element elem:urlsum){
    			ProfesserInfo2014302580307 a=new ProfesserInfo2014302580307();
    			a.url=elem.attr("abs:href");
    			a.getDoc();
    			a.getTitle();
    			a.getName();
    			a.getResDir();
    			a.getEmail();
    			a.getPhone();
    			//�洢��mysql
    			sql = "insert into professor(name,email,phone,info) values('"+a.name+"','"+a.email+"','"+a.phone+"','"+a.ResDir+"')";
    			result = stmt.executeUpdate(sql);
            }
            long time2=System.currentTimeMillis();
            //����ʱ��
            long disparity1=time2-time1;
            System.out.println("���̣߳�"+disparity1);
//            long time3=System.currentTimeMillis();
//            for(Element elem:urlsum){
//    			Thread1 t1=new Thread1(elem.attr("abs:href"));
//    			t1.start();
//    			sql = "insert into professor(name,email,phone,info) values('"+t1.name+"','"+t1.email+"','"+t1.phone+"','"+t1.ResDir+"')";
//    			result = stmt.executeUpdate(sql);
//            }
//            long time4=System.currentTimeMillis();
//            long disparity2=time4-time3;
//            System.out.println("���̣߳�"+disparity2);
            System.out.println("���ݿ�����ɹ�");
        } catch (SQLException e) {
            System.out.println("MySQL��������");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            conn.close();
        }
 
    }
 
}

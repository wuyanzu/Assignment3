import java.sql.Connection;
import java.sql.DriverManager;

public class Thread2 {
	String name;
	String email;
	String phone;
	String ResDir;
	public void run(){
		String sql;
		Connection conn = null;
		sql = "insert into professor(name,email,phone,info) values('"+name+"','"+email+"','"+phone+"','"+ResDir+"')";
		result = stmt.executeUpdate(sql);
	}
}
